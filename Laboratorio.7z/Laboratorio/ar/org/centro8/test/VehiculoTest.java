package ar.org.centro8.test;

import ar.org.centro8.entities.AutoClasico;
import ar.org.centro8.entities.AutoNuevo;
import ar.org.centro8.entities.Colectivo;
import ar.org.centro8.entities.Radio;

public class VehiculoTest {
    public static void main(String[] args) {

        System.out.println("--AutoClasico1--");
        AutoClasico ac1 = new AutoClasico("Rojo", "Fiat", "Palio", 150000);
        System.out.println(ac1);
        System.out.println(" ");

        System.out.println("--AutoClasico2--");
        AutoClasico ac2 = new AutoClasico("Azul", "Vw", "Gol", 250000, new Radio("Philips", 20));
        System.out.println(ac2);
        System.out.println(" ");

        System.out.println("--AutoNuevo1--");
        AutoNuevo an1 = new AutoNuevo("Rojo", "Ford", "Fiesta", 10000, new Radio("Pionner", 18));
        System.out.println(an1);
        System.out.println(" ");

        System.out.println("------Agregar Una Radio a AutoClasico1-------");
        ac1.agregarRadio(new Radio("Yamaha", 19));
        System.out.println(ac1);
        System.out.println(" ");

        System.out.println("-------Colectivo------");
        Colectivo cc1 = new Colectivo("Rojo", "Mercedez Benz", "30 pax");
        System.out.println(cc1);
        System.out.println(" ");

        System.out.println("----Agregar Radio a colectivo----");
        cc1.agregarRadio(new Radio("Fender", 20));
        System.out.println(cc1);

    }

}

package ar.org.centro8.entities;

public class AutoNuevo extends Vehiculo {
    
    
    public AutoNuevo (String color, String marca, String modelo, double precio, Radio radio){
        super(color, marca, modelo, precio, radio);
    }
    
    public AutoNuevo (String color, String marca, String modelo, Radio radio){
        super(color, marca, modelo, radio);
    }
    
    
}
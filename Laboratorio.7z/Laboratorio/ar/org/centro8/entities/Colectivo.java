package ar.org.centro8.entities;

public final class Colectivo extends Vehiculo {
    
    public Colectivo(String color, String marca, String modelo, double precio, Radio radio){
        super(color, marca, modelo, precio, radio);
    }

    public Colectivo(String color, String marca, String modelo, double precio){
        super(color, marca, modelo, precio);
    }
    
    public Colectivo(String color, String marca, String modelo){
        super(color, marca, modelo) ;
    }
    
}

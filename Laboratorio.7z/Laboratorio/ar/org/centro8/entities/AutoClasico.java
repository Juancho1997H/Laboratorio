package ar.org.centro8.entities;

public class AutoClasico extends Vehiculo {


    public AutoClasico (String color, String marca, String modelo, double precio, Radio radio){
        super(color, marca, modelo, precio, radio);
    
    }
    public AutoClasico (String color, String marca, String modelo, double precio){
        super(color, marca, modelo, precio);
    
    }
    public AutoClasico (String color, String marca, String modelo, Radio radio){
        super(color, marca, modelo, radio);
    
    }

    
}